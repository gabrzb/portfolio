import type { AboutSkill, AboutStat } from "../types/content";

export const aboutSkills: AboutSkill[] = [
  {
    title: "Frontend",
    description: "React, Angular, TypeScript, Tailwind CSS, Next.js",
    command: "Desenvolvimento Web",
    delayMs: 0,
    iconAnimationClassName: "animate-float",
  },
  {
    title: "Backend",
    description: "Node.js, Express, Spring Boot, PostgreSQL, MongoDB",
    command: "RESTful & APIs",
    delayMs: 200,
    iconAnimationClassName: "animate-float animation-delay-200",
  },
  {
    title: "Ferramentas",
    description: "Git, Docker, VS Code, Figma, Blender, DaVinci Resolve",
    command: "Múltiplas tecnologias",
    delayMs: 400,
    iconAnimationClassName: "animate-float animation-delay-400",
  },
];

export const aboutStats: AboutStat[] = [
  { value: 5, suffix: "+", label: "Anos de Experiência", delayMs: 0 },
  { value: 50, suffix: "+", label: "Projetos Completos", delayMs: 100 },
  { value: 100, suffix: "%", label: "Satisfação Cliente", delayMs: 200 },
  { value: "infinity", label: "Aprendizado Contínuo", delayMs: 300 },
];
