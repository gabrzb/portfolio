import type { NavItem } from "../types/content";

export const navItems: NavItem[] = [
  { href: "#hero", label: "home" },
  { href: "#about", label: "sobre" },
  { href: "#education", label: "formação" },
  { href: "#career", label: "carreira" },
  { href: "#projects", label: "projetos" },
  { href: "#contact", label: "contato" },
];
