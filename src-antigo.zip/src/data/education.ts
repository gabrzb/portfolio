import type { Certificate } from "../types/content";

export const certificates: Certificate[] = [
  {
    id: 1,
    title: "Bacharelado em Ciência da Computação",
    provider: "UniAnchieta",
    year: "2025",
    duration: "4 anos",
    skills: ["Desenvolvimento de Software", "Metodologias Ágeis", "IA", "Redes de Computadores", "Segurança da Informação", "Clean Code"],
  },
  {
    id: 2,
    title: "Become a WordPress Developer: Unlocking Power With Code",
    provider: "Udemy",
    year: "2025",
    duration: "46h",
    skills: ["Wordpress Development", "Hooks", "REST API", "Plugins" ],
  },
  {
    id: 3,
    title: "Network Basics",
    provider: "Cisco",
    year: "2025",
    duration: "22h",
    skills: ["Fundamentos de Redes", "TCP/IP", "Modelos", "Equipamentos"],
  },
  {
    id: 4,
    title: "Introduction to Packet Tracer",
    provider: "Cisco",
    year: "2025",
    duration: "--",
    skills: ["Cisco Packet Tracer", "Simulação de Redes", "Topologias", "Conectividade"],
  },
  {
    id: 5,
    title: "Técnico em Informática para Internet",
    provider: "ETEC Vasco Antonio Venchiarutti",
    year: "2021",
    duration: "3 anos",
    skills: ["Lógica de Programação", "Programação Web", "Noções de UI/UX", "Banco de Dados", "Manutenção de Computadores"],
  },
];
