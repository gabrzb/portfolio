import type { ProfileContact, SocialLink } from "../types/content";

export const profileContact: ProfileContact = {
  name: "Gabriel Zaniqueli Beltrame",
  role: "Desenvolvedor Full Stack",
  email: "contatozaniqueli@gmail.com",
};

export const socialLinks: SocialLink[] = [
  { href: "https://github.com/gabrzb", label: "GitHub", platform: "github" },
  { href: "https://www.linkedin.com/in/gabriel-zaniqueli/", label: "LinkedIn", platform: "linkedin" },
];
