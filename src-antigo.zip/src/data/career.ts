import type { Job } from "../types/content";

export const jobs: Job[] = [
  {
    id: 1,
    title: "Estágio em Programação Web e Suporte",
    company: "Manghá Agência",
    location: "Jundiaí, SP",
    period: "2025 - Presente",
    current: true,
    description: [
      "Liderança técnica em projetos de grande escala com milhões de usuários",
      "Arquitetura e desenvolvimento de microserviços em Node.js",
      "Implementação de CI/CD pipelines e práticas DevOps",
      "Mentoria de junior developers e code reviews",
    ],
    technologies: ["Wordpress", "PHP", "Frontend", "Docker", "AWS", "TypeScript"],
  },
  {
    id: 2,
    title: "Estágio em Suporte de TI",
    company: "SOBIT Soluções em Tecnologia",
    location: "Várzea Paulista, SP",
    period: "2024 - 2025",
    current: false,
    description: [
      "Desenvolvimento de aplicações web responsivas com React",
      "APIs RESTful com Express.js e Node.js",
      "Otimização de performance e SEO",
      "Implementação de testes automatizados e E2E",
    ],
    technologies: ["React", "Express.js", "MongoDB", "Jest", "Vite", "JavaScript"],
  },
  {
    id: 3,
    title: "Aprendiz de Mecânico de Manutenção",
    company: "Sulzer",
    location: "Jundiaí, SP",
    period: "2022 - 2023",
    current: false,
    description: [
      "Desenvolvimento de interfaces responsivas e acessíveis",
      "Integração com APIs externas",
      "Implementação de design systems",
      "Testes unitários com Jest e React Testing Library",
    ],
    technologies: ["React", "CSS3", "JavaScript", "Redux", "Webpack"],
  },
];
